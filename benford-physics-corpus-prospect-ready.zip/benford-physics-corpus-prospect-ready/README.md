# benford-physics-corpus

**Prospect-facing Python research project:** a reproducible pipeline for testing whether numerical values in physics papers follow Benford’s Law.

This project combines scientific text mining, numerical parsing, statistical testing, and clean Python package structure. It is designed to demonstrate competence in Python, data cleaning, reproducible analysis, and research-oriented software development.

## Research question

Do numerical values extracted from physics papers follow the expected Benford first-significant-digit distribution?

Benford’s Law predicts that naturally occurring numerical datasets often begin with smaller digits more frequently than larger ones:

```text
P(d) = log10(1 + 1/d), where d ∈ {1, ..., 9}
```

Expected distribution:

| First digit | Expected probability |
|---:|---:|
| 1 | 30.10% |
| 2 | 17.61% |
| 3 | 12.49% |
| 4 | 9.69% |
| 5 | 7.92% |
| 6 | 6.69% |
| 7 | 5.80% |
| 8 | 5.12% |
| 9 | 4.58% |

## What the pipeline does

1. Loads scientific text from `.txt` files or extracted PDF text.
2. Extracts numerical values, including decimals and scientific notation.
3. Filters out values that are unlikely to represent scientific measurements.
4. Computes first-significant-digit frequencies.
5. Compares observed frequencies with Benford expectations.
6. Reports chi-square statistic, MAD, RMSE, and KL divergence.
7. Produces publication-style summary tables.

## Repository structure

```text
benford-physics-corpus/
├── README.md
├── requirements.txt
├── pyproject.toml
├── src/
│   └── benford_physics/
│       ├── __init__.py
│       ├── analysis.py
│       ├── extraction.py
│       ├── metrics.py
│       └── report.py
├── examples/
│   └── demo_text_analysis.py
└── tests/
    ├── test_extraction.py
    └── test_metrics.py
```

## Quick start

```bash
pip install -r requirements.txt
python examples/demo_text_analysis.py
```

## Example output

```text
Digit  Observed  Expected  Difference
1      0.2857    0.3010   -0.0153
2      0.1429    0.1761   -0.0332
3      0.1429    0.1249    0.0180
...
Chi-square statistic: 1.8421
Mean absolute deviation: 0.0287
RMSE: 0.0345
KL divergence: 0.0189
```

## Prospect summary

I am building a Python research pipeline that applies Benford’s Law to scientific corpora, starting with physics papers. The project demonstrates practical competence in Python, text extraction, numerical parsing, statistical comparison, clean package structure, and reproducible research workflows.

## Planned next steps

- Add arXiv metadata ingestion.
- Add PDF text extraction with PyMuPDF.
- Separate numbers from abstracts, body text, equations, and tables.
- Compare distributions by year and physics subfield.
- Add plots for observed versus expected digit distributions.
- Package the pipeline as a command-line tool.
