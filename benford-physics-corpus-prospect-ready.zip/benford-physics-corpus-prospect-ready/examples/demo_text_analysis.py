"""Demo analysis for benford-physics-corpus.

Run with:
    python examples/demo_text_analysis.py
"""

from benford_physics.analysis import analyze_text
from benford_physics.report import format_full_report


DEMO_TEXT = """
A detector array recorded 123 calibration events, 47 reference measurements,
0.0031 seconds of timing uncertainty, 9.81 m/s^2 acceleration, 6.022e23
particles per mole, 2.9979e8 m/s for light speed, 1.602e-19 coulombs for
elementary charge, 8.617e-5 eV/K for the Boltzmann constant, 137.036 for
the inverse fine-structure constant, 511 keV electron rest energy, 938.27
MeV proton mass, and 1.054e-34 J*s for reduced Planck's constant.

A simulation produced 214 trajectories, 389 successful runs, 144 boundary
conditions, 55 rejected parameter sets, 34 low-energy states, 21 high-energy
states, 13 unstable oscillations, and 8 convergent solutions.
"""


def main() -> None:
    result = analyze_text(DEMO_TEXT)
    print(format_full_report(result))


if __name__ == "__main__":
    main()
