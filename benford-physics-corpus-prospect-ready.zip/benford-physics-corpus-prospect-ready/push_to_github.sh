#!/usr/bin/env bash
set -e

git init
git add .
git commit -m "Add prospect-ready Benford physics corpus scaffold"
git branch -M main
git remote remove origin 2>/dev/null || true
git remote add origin https://github.com/LaurenLittleWolf/benford-physics-corpus.git
git push -u origin main
