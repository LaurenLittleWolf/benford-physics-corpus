"""Statistical metrics for Benford analysis."""

from __future__ import annotations

import math
from collections.abc import Mapping


def benford_probabilities() -> dict[int, float]:
    """Return expected Benford probabilities for digits 1 through 9."""
    return {digit: math.log10(1 + 1 / digit) for digit in range(1, 10)}


def normalize_counts(counts: Mapping[int, int]) -> dict[int, float]:
    """Convert raw first-digit counts into proportions."""
    total = sum(counts.get(digit, 0) for digit in range(1, 10))

    if total == 0:
        return {digit: 0.0 for digit in range(1, 10)}

    return {digit: counts.get(digit, 0) / total for digit in range(1, 10)}


def chi_square_statistic(
    observed_proportions: Mapping[int, float],
    sample_size: int,
    expected_proportions: Mapping[int, float] | None = None,
) -> float:
    """Compute chi-square statistic using proportions and sample size."""
    expected = expected_proportions or benford_probabilities()
    statistic = 0.0

    for digit in range(1, 10):
        observed_count = observed_proportions.get(digit, 0.0) * sample_size
        expected_count = expected[digit] * sample_size

        if expected_count > 0:
            statistic += ((observed_count - expected_count) ** 2) / expected_count

    return statistic


def mean_absolute_deviation(
    observed: Mapping[int, float],
    expected: Mapping[int, float] | None = None,
) -> float:
    """Compute mean absolute deviation across digits 1 through 9."""
    expected_values = expected or benford_probabilities()

    return sum(
        abs(observed.get(digit, 0.0) - expected_values[digit])
        for digit in range(1, 10)
    ) / 9


def rmse(
    observed: Mapping[int, float],
    expected: Mapping[int, float] | None = None,
) -> float:
    """Compute root mean squared error across first-digit proportions."""
    expected_values = expected or benford_probabilities()

    squared_error = sum(
        (observed.get(digit, 0.0) - expected_values[digit]) ** 2
        for digit in range(1, 10)
    )

    return math.sqrt(squared_error / 9)


def kl_divergence(
    observed: Mapping[int, float],
    expected: Mapping[int, float] | None = None,
    epsilon: float = 1e-12,
) -> float:
    """Compute KL divergence D_KL(observed || expected)."""
    expected_values = expected or benford_probabilities()
    total = 0.0

    for digit in range(1, 10):
        p = max(observed.get(digit, 0.0), epsilon)
        q = max(expected_values[digit], epsilon)
        total += p * math.log(p / q)

    return total
