"""Extraction utilities for scientific numerical text.

The goal is not merely to find digits. Scientific papers contain equation numbers,
page numbers, dates, references, dimensions, constants, and scientific notation.
This module provides a conservative starting point for extracting candidate
numerical values from text.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Iterable


NUMERIC_TOKEN_RE = re.compile(
    r"""
    (?<![A-Za-z])
    [-+]?
    (?:
        (?:\d+\.\d*) |
        (?:\.\d+) |
        (?:\d+)
    )
    (?:[eE][-+]?\d+)?
    (?![A-Za-z])
    """,
    re.VERBOSE,
)


@dataclass(frozen=True)
class NumericToken:
    """A numeric token extracted from text.

    Attributes:
        raw: The original string form.
        value: The parsed floating-point value.
        start: Start character offset in the source text.
        end: End character offset in the source text.
    """

    raw: str
    value: float
    start: int
    end: int


def parse_numeric_token(raw: str) -> float | None:
    """Parse a numeric token into a finite float."""
    try:
        value = float(raw)
    except ValueError:
        return None

    if math.isnan(value) or math.isinf(value):
        return None

    return value


def extract_numeric_tokens(text: str) -> list[NumericToken]:
    """Extract parseable numeric tokens from text."""
    tokens: list[NumericToken] = []

    for match in NUMERIC_TOKEN_RE.finditer(text):
        raw = match.group(0)
        value = parse_numeric_token(raw)

        if value is None:
            continue

        tokens.append(
            NumericToken(
                raw=raw,
                value=value,
                start=match.start(),
                end=match.end(),
            )
        )

    return tokens


def first_significant_digit(value: str | int | float) -> int | None:
    """Return the first significant digit of a number.

    Examples:
        123 -> 1
        0.0047 -> 4
        -9.81 -> 9
        6.022e23 -> 6
    """
    parsed = parse_numeric_token(str(value))

    if parsed is None:
        return None

    number = abs(parsed)

    if number == 0:
        return None

    while number < 1:
        number *= 10

    while number >= 10:
        number /= 10

    digit = int(number)
    return digit if 1 <= digit <= 9 else None


def first_digits(values: Iterable[str | int | float]) -> list[int]:
    """Return valid first significant digits for an iterable of values."""
    digits: list[int] = []

    for value in values:
        digit = first_significant_digit(value)
        if digit is not None:
            digits.append(digit)

    return digits
