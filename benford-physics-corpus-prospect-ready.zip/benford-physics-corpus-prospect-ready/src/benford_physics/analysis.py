"""High-level Benford analysis workflow."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass

from .extraction import extract_numeric_tokens, first_significant_digit
from .metrics import (
    benford_probabilities,
    chi_square_statistic,
    kl_divergence,
    mean_absolute_deviation,
    normalize_counts,
    rmse,
)


@dataclass(frozen=True)
class DigitAnalysis:
    """Result object for a Benford first-digit analysis."""

    sample_size: int
    counts: dict[int, int]
    observed: dict[int, float]
    expected: dict[int, float]
    chi_square: float
    mad: float
    rmse: float
    kl_divergence: float


def analyze_text(text: str) -> DigitAnalysis:
    """Analyze first-significant-digit distribution in a text string."""
    tokens = extract_numeric_tokens(text)
    digits: list[int] = []

    for token in tokens:
        digit = first_significant_digit(token.value)
        if digit is not None:
            digits.append(digit)

    counts_raw = Counter(digits)
    counts = {digit: counts_raw.get(digit, 0) for digit in range(1, 10)}
    observed = normalize_counts(counts)
    expected = benford_probabilities()
    sample_size = len(digits)

    return DigitAnalysis(
        sample_size=sample_size,
        counts=counts,
        observed=observed,
        expected=expected,
        chi_square=chi_square_statistic(observed, sample_size),
        mad=mean_absolute_deviation(observed, expected),
        rmse=rmse(observed, expected),
        kl_divergence=kl_divergence(observed, expected),
    )
