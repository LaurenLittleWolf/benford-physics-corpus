"""Human-readable report helpers."""

from __future__ import annotations

from .analysis import DigitAnalysis


def format_digit_table(result: DigitAnalysis) -> str:
    """Return a plain-text table comparing observed and expected proportions."""
    lines = [
        "Digit  Count  Observed  Expected  Difference",
        "-----  -----  --------  --------  ----------",
    ]

    for digit in range(1, 10):
        observed = result.observed[digit]
        expected = result.expected[digit]
        difference = observed - expected

        lines.append(
            f"{digit:>5}  "
            f"{result.counts[digit]:>5}  "
            f"{observed:>8.4f}  "
            f"{expected:>8.4f}  "
            f"{difference:>10.4f}"
        )

    return "\n".join(lines)


def format_summary(result: DigitAnalysis) -> str:
    """Return a compact summary of statistical comparison metrics."""
    return (
        f"Sample size: {result.sample_size}\n"
        f"Chi-square statistic: {result.chi_square:.4f}\n"
        f"Mean absolute deviation: {result.mad:.4f}\n"
        f"RMSE: {result.rmse:.4f}\n"
        f"KL divergence: {result.kl_divergence:.4f}"
    )


def format_full_report(result: DigitAnalysis) -> str:
    """Return a complete plain-text analysis report."""
    return f"{format_digit_table(result)}\n\n{format_summary(result)}"
