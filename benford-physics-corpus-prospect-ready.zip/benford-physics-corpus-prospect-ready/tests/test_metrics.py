from benford_physics.analysis import analyze_text
from benford_physics.metrics import benford_probabilities


def test_benford_probabilities_sum_to_one():
    total = sum(benford_probabilities().values())
    assert abs(total - 1.0) < 1e-12


def test_analyze_text_returns_expected_sample_size():
    result = analyze_text("123 234 345 0.0047 5.9e10")
    assert result.sample_size == 5
    assert result.counts[1] == 1
    assert result.counts[2] == 1
    assert result.counts[3] == 1
    assert result.counts[4] == 1
    assert result.counts[5] == 1
