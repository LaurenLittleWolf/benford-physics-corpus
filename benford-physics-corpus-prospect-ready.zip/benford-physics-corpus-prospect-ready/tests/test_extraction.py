from benford_physics.extraction import extract_numeric_tokens, first_significant_digit


def test_extract_numeric_tokens_scientific_notation():
    text = "The constants were 6.022e23, 1.602e-19, and 9.81."
    tokens = extract_numeric_tokens(text)
    assert [token.raw for token in tokens] == ["6.022e23", "1.602e-19", "9.81"]


def test_first_significant_digit_examples():
    assert first_significant_digit("123") == 1
    assert first_significant_digit("0.0047") == 4
    assert first_significant_digit("-9.81") == 9
    assert first_significant_digit("6.022e23") == 6
    assert first_significant_digit("0") is None
